## Código del tutorial: Como hacer una Sección Desplegable con HTML, CSS (SASS) y Jquery
### [Tutorial: Como hacer una Sección Desplegable con HTML, CSS (SASS) y Jquery](http://www.falconmasters.com/web-design/seccion-desplegable-jquery/)

![Tutorial: Como hacer una Sección Desplegable con HTML, CSS (SASS) y Jquery](https://raw.githubusercontent.com/falconmasters/Seccion-Desplegable-con-Jquery/master/img/Como-hacer-una-Secci%C3%B3n-Desplegable-con-HTML-CSS-SASS-y-Jquery.jpg)

Por: [FalconMasters](http://www.falconmasters.com)